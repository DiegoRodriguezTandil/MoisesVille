<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


return [
    'About' => 'Acerca de',
    'Contact' => 'Contacto',
    'Home' => 'Inicio',
    'Logout' => 'Salir',
    'My Company' => 'Mi Empresa',
    'Sign In' => 'Entrar',
    'Sign Up' => 'Registrarse',
    'Status' => 'Estado'
    ];