use moisesville;

delete from user where id > -1;

insert into user(id,username,password,firstName) values(1,'admin','admin','Sistema');
insert into user(id,username,password,firstName) values(2,'Visitante','Visitante','Visitante');
insert into user(id,username,password,firstName) values(3,'javier','javier','Javier Becker');
insert into user(id,username,password,firstName) values(4,'eva','eva','Eva Rosenthal');
insert into user(id,username,password,firstName) values(5,'golde','golde','Golde de Gerson');
insert into user(id,username,password,firstName) values(6,'fanny','fanny','Fanny Galagovsky');
insert into user(id,username,password,firstName) values(7,'carina','carina','Carina Sanchez');
insert into user(id,username,password,firstName) values(8,'cristina','cristina','Cristina Esquivel');
insert into user(id,username,password,firstName) values(9,'beatriz','beatriz','Beatriz F. de Smulovich');
insert into user(id,username,password,firstName) values(10,'elsa','elsa','Elsa Scarafía');
insert into user(id,username,password,firstName) values(11,'lilian','lilian','Lilian Vazquez');
insert into user(id,username,password,firstName) values(12,'leandro','leandro','Leandro Panigutti');
insert into user(id,username,password,firstName) values(13,'carralde','carralde','Cristina Arralde');
insert into user(id,username,password,firstName) values(14,'luciana','luciana','Luciana Boarotto');
insert into user(id,username,password,firstName) values(15,'beatriz','beatriz','Beatriz Mendieta');
insert into user(id,username,password,firstName) values(16,'hilda','hilda','Hilda Zamory');

insert into organizacion(id, nombre, organizacionTipo_id) values (1,'Museo Hisórico Comunal de la Colonización Judía', 5);
update user set organizacion_id = 1;